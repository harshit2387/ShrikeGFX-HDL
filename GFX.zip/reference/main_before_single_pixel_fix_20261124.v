// Single-pixel and arbitrary straight-line demo for a 240x240 ST7789.
// Change PIXEL_X/Y or LINE_X0/Y0/LINE_X1/Y1, then rebuild the bitstream.
// Requires the existing shrike_gfx_st7789 library modules in the project.
(* top *)
module mux21 #(
    parameter integer CLK_HZ = 50000000,
    parameter [15:0] LCD_WIDTH = 16'd240,
    parameter [15:0] LCD_HEIGHT = 16'd240,
    parameter [15:0] SPI_HALF_PERIOD = 16'd25,
    parameter [7:0] MADCTL_VAL = 8'h00,
    parameter [7:0] COLMOD_VAL = 8'h55,
    parameter integer CS_PIN_PRESENT = 1,
    parameter integer RESET_PIN_PRESENT = 1,
    parameter integer X_OFFSET = 0,
    parameter integer Y_OFFSET = 0,

    parameter integer PIXEL_ENABLE = 1,
    parameter [15:0] PIXEL_X = 16'd120,
    parameter [15:0] PIXEL_Y = 16'd120,
    parameter [15:0] PIXEL_COLOR = 16'hF800,

    parameter integer LINE_ENABLE = 1,
    parameter [15:0] LINE_X0 = 16'd20,
    parameter [15:0] LINE_Y0 = 16'd200,
    parameter [15:0] LINE_X1 = 16'd220,
    parameter [15:0] LINE_Y1 = 16'd40,
    parameter [15:0] LINE_COLOR = 16'h07FF,

    parameter [15:0] BACKGROUND_COLOR = 16'h0000
) (
    (* iopad_external_pin, clkbuf_inhibit *) input wire clk,
    (* iopad_external_pin *) output wire clk_en,
    (* iopad_external_pin *) output wire lcd_sck,
    (* iopad_external_pin *) output wire lcd_sck_oe,
    (* iopad_external_pin *) output wire lcd_mosi,
    (* iopad_external_pin *) output wire lcd_mosi_oe,
    (* iopad_external_pin *) output wire lcd_cs_n,
    (* iopad_external_pin *) output wire lcd_cs_n_oe,
    (* iopad_external_pin *) output wire lcd_dc,
    (* iopad_external_pin *) output wire lcd_dc_oe,
    (* iopad_external_pin *) output wire lcd_reset_n,
    (* iopad_external_pin *) output wire lcd_reset_n_oe,
    (* iopad_external_pin *) output wire lcd_backlight,
    (* iopad_external_pin *) output wire lcd_backlight_oe
);

    function integer clog2;
        input integer value;
        integer v;
        begin
            v = value - 1;
            clog2 = 0;
            while (v > 0) begin
                clog2 = clog2 + 1;
                v = v >> 1;
            end
            if (clog2 < 1)
                clog2 = 1;
        end
    endfunction

    localparam integer SPI_HZ =
        CLK_HZ / (2 * SPI_HALF_PERIOD);

    localparam integer DISPLAY_MAX_DIM =
        (LCD_WIDTH > LCD_HEIGHT) ? LCD_WIDTH : LCD_HEIGHT;

    localparam integer COORD_BITS = clog2(DISPLAY_MAX_DIM);

    localparam [15:0] X_END = LCD_WIDTH - 16'd1;
    localparam [15:0] Y_END = LCD_HEIGHT - 16'd1;

    localparam integer LINE_DX =
        (LINE_X1 >= LINE_X0) ? (LINE_X1 - LINE_X0) : (LINE_X0 - LINE_X1);

    localparam integer LINE_DY =
        (LINE_Y1 >= LINE_Y0) ? (LINE_Y1 - LINE_Y0) : (LINE_Y0 - LINE_Y1);

    localparam integer LINE_MAJOR =
        (LINE_DX >= LINE_DY) ? LINE_DX : LINE_DY;

    localparam [15:0] LINE_X_MIN =
        (LINE_X0 <= LINE_X1) ? LINE_X0 : LINE_X1;

    localparam [15:0] LINE_X_MAX =
        (LINE_X0 >= LINE_X1) ? LINE_X0 : LINE_X1;

    localparam [15:0] LINE_Y_MIN =
        (LINE_Y0 <= LINE_Y1) ? LINE_Y0 : LINE_Y1;

    localparam [15:0] LINE_Y_MAX =
        (LINE_Y0 >= LINE_Y1) ? LINE_Y0 : LINE_Y1;

    reg logic_rst_n = 1'b0;
    reg [15:0] pixel_rgb565;

    wire start_ready;
    wire [15:0] pixel_x;
    wire [15:0] pixel_y;
    wire pixel_active;
    wire display_busy;
    wire display_done;
    wire init_done;

    wire line_in_bounds;
    wire [15:0] x_from_start;
    wire [15:0] y_from_start;
    wire [31:0] line_x_term;
    wire [31:0] line_y_term;
    wire [31:0] line_cross;
    wire [32:0] line_cross_twice;
    wire [32:0] line_major_extended;
    wire line_tie_round_up;
    wire line_pixel;

    assign clk_en = 1'b1;

    assign lcd_sck_oe = 1'b1;
    assign lcd_mosi_oe = 1'b1;
    assign lcd_cs_n_oe = 1'b1;
    assign lcd_dc_oe = 1'b1;
    assign lcd_reset_n_oe = 1'b1;
    assign lcd_backlight_oe = 1'b1;
    assign lcd_backlight = 1'b1;

    always @(posedge clk)
        logic_rst_n <= 1'b1;

    assign line_in_bounds =
        (pixel_x >= LINE_X_MIN) && (pixel_x <= LINE_X_MAX) &&
        (pixel_y >= LINE_Y_MIN) && (pixel_y <= LINE_Y_MAX);

    assign x_from_start =
        (LINE_X1 >= LINE_X0) ? (pixel_x - LINE_X0) : (LINE_X0 - pixel_x);

    assign y_from_start =
        (LINE_Y1 >= LINE_Y0) ? (pixel_y - LINE_Y0) : (LINE_Y0 - pixel_y);

    // LINE_DX and LINE_DY are parameters, so these are constant-coefficient
    // operations after elaboration.
    assign line_x_term = x_from_start * LINE_DY;
    assign line_y_term = y_from_start * LINE_DX;

    assign line_cross =
        (line_x_term >= line_y_term)
            ? (line_x_term - line_y_term)
            : (line_y_term - line_x_term);

    assign line_cross_twice = {line_cross, 1'b0};
    assign line_major_extended = LINE_MAJOR;

    // At an exact half-pixel tie, choose one side so the line stays one pixel
    // wide instead of lighting both neighboring pixels.
    assign line_tie_round_up =
        (LINE_DX >= LINE_DY)
            ? (line_y_term > line_x_term)
            : (line_x_term > line_y_term);

    assign line_pixel =
        (LINE_MAJOR == 0)
            ? ((pixel_x == LINE_X0) && (pixel_y == LINE_Y0))
            : (line_in_bounds &&
               ((line_cross_twice < line_major_extended) ||
                ((line_cross_twice == line_major_extended) &&
                 line_tie_round_up)));

    always @* begin
        pixel_rgb565 = BACKGROUND_COLOR;

        if (LINE_ENABLE && line_pixel)
            pixel_rgb565 = LINE_COLOR;

        // Draw the single pixel last so it stays visible where it crosses
        // the line.
        if (PIXEL_ENABLE &&
            (pixel_x == PIXEL_X) &&
            (pixel_y == PIXEL_Y))
            pixel_rgb565 = PIXEL_COLOR;
    end

    shrike_gfx_st7789 #(
        .CLK_HZ(CLK_HZ),
        .SPI_HZ(SPI_HZ),
        .CS_PIN_PRESENT(CS_PIN_PRESENT),
        .RESET_PIN_PRESENT(RESET_PIN_PRESENT),
        .X_OFFSET(X_OFFSET),
        .Y_OFFSET(Y_OFFSET),
        .MADCTL_VAL(MADCTL_VAL),
        .COLMOD_VAL(COLMOD_VAL),
        .COORD_BITS(COORD_BITS)
    ) display (
        .clk(clk),
        .rst_n(logic_rst_n),
        .start(start_ready),
        .start_ready(start_ready),
        .win_x0(16'd0),
        .win_y0(16'd0),
        .win_x1(X_END),
        .win_y1(Y_END),
        .pixel_x(pixel_x),
        .pixel_y(pixel_y),
        .pixel_active(pixel_active),
        .pixel_rgb565(pixel_rgb565),
        .busy(display_busy),
        .done(display_done),
        .init_done(init_done),
        .spi_sck(lcd_sck),
        .spi_mosi(lcd_mosi),
        .display_cs_n(lcd_cs_n),
        .display_dc(lcd_dc),
        .display_rst_n(lcd_reset_n)
    );

endmodule