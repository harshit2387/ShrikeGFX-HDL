// ST7789 top that combines the known-good ForgeFPGA I/O style with shrike-gfx.
// The 1 MHz SPI default matches the previously verified SPI_HALF_PERIOD=25
// setting at 50 MHz. The pixel shader keeps a red background and overlays the
// reusable bar, scope, and text widgets.
(* top *)
module mux21 #(
    parameter integer CLK_HZ = 50000000,
    parameter [15:0] LCD_WIDTH = 16'd240,
    parameter [15:0] LCD_HEIGHT = 16'd240,
    parameter [15:0] SPI_HALF_PERIOD = 16'd25,
    parameter [7:0] MADCTL_VAL = 8'h00,
    parameter [7:0] COLMOD_VAL = 8'h55,
    parameter [15:0] FILL_COLOR = 16'hF800,
    parameter BACKLIGHT_ON = 1'b1,
    parameter BACKLIGHT_OFF = 1'b0,
    parameter integer CS_PIN_PRESENT = 1,
    parameter integer RESET_PIN_PRESENT = 1,
    parameter integer X_OFFSET = 0,
    parameter integer Y_OFFSET = 0
) (
    (* iopad_external_pin, clkbuf_inhibit *) input wire clk,
    (* iopad_external_pin *) output wire clk_en,
    (* iopad_external_pin *) output wire lcd_sck,
    (* iopad_external_pin *) output wire lcd_sck_oe,
    (* iopad_external_pin *) output wire lcd_mosi,
    (* iopad_external_pin *) output wire lcd_mosi_oe,
    (* iopad_external_pin *) output wire lcd_cs_n,
    (* iopad_external_pin *) output wire lcd_cs_n_oe,
    (* iopad_external_pin *) output wire lcd_dc,
    (* iopad_external_pin *) output wire lcd_dc_oe,
    (* iopad_external_pin *) output wire lcd_reset_n,
    (* iopad_external_pin *) output wire lcd_reset_n_oe,
    (* iopad_external_pin *) output wire lcd_backlight,
    (* iopad_external_pin *) output wire lcd_backlight_oe
);
    localparam [15:0] X_END = (LCD_WIDTH != 16'd0) ? LCD_WIDTH - 16'd1 : 16'd0;
    localparam [15:0] Y_END = (LCD_HEIGHT != 16'd0) ? LCD_HEIGHT - 16'd1 : 16'd0;
    function integer clog2;
        input integer value;
        integer v;
        begin
            v = value - 1;
            clog2 = 0;
            while (v > 0) begin
                clog2 = clog2 + 1;
                v = v >> 1;
            end
            if (clog2 < 1) clog2 = 1;
        end
    endfunction

    function integer max_int;
        input integer a;
        input integer b;
        begin max_int = (a > b) ? a : b; end
    endfunction

    localparam integer SPI_HZ = CLK_HZ / (2 * SPI_HALF_PERIOD);
    localparam integer DISPLAY_MAX_DIM = (LCD_WIDTH > LCD_HEIGHT) ? LCD_WIDTH : LCD_HEIGHT;
    localparam integer COORD_BITS = max_int(1, clog2(DISPLAY_MAX_DIM));

    reg logic_rst_n = 1'b0;
    reg [7:0] duty_fill_width;
    reg [127:0] trace_history;
    wire start_ready;
    wire display_busy, display_done, init_done;
    wire [15:0] pixel_x, pixel_y, pixel_rgb565;
    wire pixel_active;

    assign clk_en = 1'b1;
    assign lcd_sck_oe = 1'b1;
    assign lcd_mosi_oe = 1'b1;
    assign lcd_cs_n_oe = 1'b1;
    assign lcd_dc_oe = 1'b1;
    assign lcd_reset_n_oe = 1'b1;
    assign lcd_backlight_oe = 1'b1;
    assign lcd_backlight = BACKLIGHT_ON ? 1'b1 : BACKLIGHT_OFF;

    // The old project has no external reset input. Hold the core reset through
    // the first clock edge; the display wrapper then applies the panel delays.
    always @(posedge clk) logic_rst_n <= 1'b1;

    always @(posedge clk) begin
        if (!logic_rst_n) begin
            duty_fill_width <= 8'd0;
            trace_history <= 128'd0;
        end else if (display_done) begin
            if (duty_fill_width >= 8'd100) duty_fill_width <= 8'd0;
            else duty_fill_width <= duty_fill_width + 1'b1;
            trace_history <= {trace_history[126:0], duty_fill_width[0]};
        end
    end

    dashboard_shader #(
        .BACKGROUND_COLOR(FILL_COLOR), .COORD_BITS(COORD_BITS)
    ) shader (
        .pixel_x(pixel_x), .pixel_y(pixel_y),
        .duty_fill_width(duty_fill_width),
        .trace_history(trace_history),
        .char_code(8'h50), // P
        .text_x0(16'd8), .text_y0(16'd8),
        .pixel_rgb565(pixel_rgb565)
    );

    shrike_gfx_st7789 #(
        .CLK_HZ(CLK_HZ),
        .SPI_HZ(SPI_HZ),
        .CS_PIN_PRESENT(CS_PIN_PRESENT),
        .RESET_PIN_PRESENT(RESET_PIN_PRESENT),
        .X_OFFSET(X_OFFSET),
        .Y_OFFSET(Y_OFFSET),
        .COORD_BITS(COORD_BITS),
        .MADCTL_VAL(MADCTL_VAL),
        .COLMOD_VAL(COLMOD_VAL)
    ) display (
        .clk(clk), .rst_n(logic_rst_n),
        .start(start_ready), .start_ready(start_ready),
        .win_x0(16'd0), .win_y0(16'd0),
        .win_x1(X_END), .win_y1(Y_END),
        .pixel_x(pixel_x), .pixel_y(pixel_y),
        .pixel_active(pixel_active), .pixel_rgb565(pixel_rgb565),
        .busy(display_busy), .done(display_done), .init_done(init_done),
        .spi_sck(lcd_sck), .spi_mosi(lcd_mosi),
        .display_cs_n(lcd_cs_n), .display_dc(lcd_dc),
        .display_rst_n(lcd_reset_n)
    );
endmodule
